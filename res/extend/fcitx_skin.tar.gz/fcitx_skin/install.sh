#!/bin/bash

for file in `ls ./`;do
	fcitx-skin-installer $file
done
